var b=document.body;
b.addEventListener("click",checkSingleLink);
b.addEventListener("mousedown",checkSingleLink);

setTimeout(function () {
    var input=document.getElementById("lst-ib");
    if (!input) {
        return setTimeout(arguments.callee,200);
    }
    input.addEventListener("keyup",function (evt) {
        if (evt instanceof KeyboardEvent && evt.keyIdentifier!=="Enter") {
            return;
        }
        delayCheckLinks();
    });
},200);

b.addEventListener("mouseover",checkSingleLink);

function checkSingleLink(evt) {
    var a=evt.target;

    if (a.tagName=="A") {
        a=[a];
    } else {
        a=[].slice.apply(a.getElementsByTagName("a"));
    }
    a.map(fixLink);
}

var tid;
function delayCheckLinks() {
    if (tid) {
        clearTimeout(tid);
    }
    tid=setTimeout(checkLinks,500);
}

function checkLinks() {
    var ires=document.getElementById("ires"),
        linksList=ires.getElementsByTagName("li"),
        cre=/\s*g\s*/,j,al,
        alist,a,i=0,l=l=linksList.length;
    for (;i<l;i++) {
        if (cre.test(linksList[i].className)) {
            alist=linksList[i].getElementsByTagName("a");
            al=alist.length;
            for (j=0;j<al;j++) {
                fixLink(alist[j]);
            }
            
        }
    }
}


var urlStarts=[
    'http://www.google.com/url?',
    'https://www.google.com/url?',
    'http://www.google.com.hk/url?',
    'https://www.google.com.hk/url?',
];

function fixLink(a) {
    if ((a.getAttribute("onmousedown")+"").indexOf("rwt(")>-1) {
        a.removeAttribute("onmousedown");
    }
    if (isTrackUrl(a.href)) {
        a.setAttribute("href",getRealUrl(a.href));
    }
}
function isTrackUrl(url) {
    var a,urls=urlStarts.slice();
    while (a=urls.pop()) {
        if (url.indexOf(a)===0) return true;
    }
    return false; 
}

function param(url) {
    if (url.indexOf("?")>-1) {
        url=url.substr(url.indexOf("?")+1)
    }
    var parts=url.split("&"),t,d={};
    while (t=parts.pop()) {
        t=t.split("=");
        d[t[0]]=decodeURIComponent(t[1]);
    }
    return d;
}

function getRealUrl(url) {
    return param(url).url;
}